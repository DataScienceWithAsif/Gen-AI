from src.mcqgenerator.logger import logging

logging.info('Hi I am gonna build first genai project....!!!')